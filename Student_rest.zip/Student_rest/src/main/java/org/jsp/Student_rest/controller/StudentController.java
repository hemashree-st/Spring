package org.jsp.Student_rest.controller;

import java.util.List;
import java.util.Optional;

import org.jsp.Student_rest.dto.StudentDTO;
import org.jsp.Student_rest.entity.Student;
import org.jsp.Student_rest.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;

//@Controller and @ResponseBody
//or
@RestController
@RequestMapping("/api/v1")
public class StudentController {
    @Autowired
    StudentService service;
	
    //save a record
	@PostMapping("/student")
	@Operation(summary ="Save a Record")
	public ResponseEntity<Student> saveStudent( @RequestBody StudentDTO dto)
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(service.saveStudent(dto));
	
	}
	
	//save multiple records
	@PostMapping("/students")
	@Operation(summary = "Save Multiple Records")
	public ResponseEntity<List<Student>> saveMultipleStudent( @RequestBody List<StudentDTO> dtos)
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(service.saveStudent(dtos));
	
	}
	
	//fetch a record by id
	@GetMapping("/students/{id}")
	@Operation(summary = "To fetch a record")
	public ResponseEntity<Optional<Student>> findStudent(@PathVariable Long id)
	{
		return ResponseEntity.status(HttpStatus.OK).body(service.findStudent(id));
	}
	
	//fetch records
	@GetMapping("/students")
	@Operation(summary = "Fetch All Records")
	public ResponseEntity<Page<Student>> fetchStudents(@RequestParam (defaultValue = "id")String sort,@RequestParam(defaultValue = "false") boolean desc,@RequestParam (defaultValue = "0") int page,@RequestParam (defaultValue = "10") int data)
	{
		return ResponseEntity.status(HttpStatus.OK).body(service.fetchAll(sort,desc,page,data));
		
	}
	
	
	
	//Delete a Record
	@DeleteMapping("/student/{id}")
	@Operation(summary = "Delete by id")
	public ResponseEntity<String> deleteRecord(@PathVariable Long id)
	{
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteRecordById(id));
	}
	
	
	//Update a Record
	@PutMapping("/student")
	@Operation(summary = "Update a Record")
	public ResponseEntity<Student> updateStudent( @RequestBody Student student)
	{
		return ResponseEntity.status(HttpStatus.OK).body(service.updateStudent(student));
	
	}
	
}
