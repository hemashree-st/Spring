package org.jsp.Student_rest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.jsp.Student_rest.dto.StudentDTO;
import org.jsp.Student_rest.entity.Student;
import org.jsp.Student_rest.exception.DataAlreadyExistsException;
import org.jsp.Student_rest.exception.DataNotFoundException;
import org.jsp.Student_rest.exception.MyExceptionHandler;
import org.jsp.Student_rest.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
	
	//swagger url-->localhost:1234/swagger-ui/index.html
	
	@Autowired
	StudentRepository repository;
		
	
	public Student saveStudent(StudentDTO dto) {
		if(!repository.existsByMobile(dto.getMobile())) 
		{
			
		   Student student=new Student(dto);
		   repository.save(student);
		   return student;
	    }
	
	//we can use constructor in Student class or write the below code in Service(here) itself
//	public Student saveStudent(StudentDTO dto)
//	{
//		Student student=new Student();
//		student.setName(dto.getName());
//		student.setMobile(dto.getMobile());
//		student.setMaths(dto.getMaths());
//		student.setScience(dto.getScience());
//		student.setEnglish(dto.getEnglish());
//		student.setPercentage((dto.getMaths()+dto.getEnglish()+dto.getScience())/3.0);
//		repository.save(student);
//		return student;
//	}
		else
		{
			throw new DataAlreadyExistsException("Mobile Number already exists: "+dto.getMobile());
		}
		
     }
	
	public List<Student> saveStudent(List<StudentDTO> dtos)
	{
		List<Student> students=new ArrayList<Student>();
		for(StudentDTO dto:dtos)
		{
			if(repository.existsByMobile(dto.getMobile()))
				throw new DataAlreadyExistsException("Mobile Number Already Exists: "+dto.getMobile());
			else
				students.add(repository.save(new Student(dto)));
		}
		return students;
	}

	
	public Optional<Student> findStudent(Long id) {
		Optional<Student> student=repository.findById(id);
		if(!student.isEmpty())
		{
			return student;
		}
		else
		{
			throw new DataNotFoundException("No record found");
		}
	}
	
	
	public  Page<Student> fetchAll(String sort, boolean desc, int page, int data) 
	{
		Sort sortBasedOn=Sort.by(sort);
		if(desc)
			sortBasedOn=sortBasedOn.descending();
		
		PageRequest pageable=PageRequest.of(page,data, sortBasedOn);
		
		Page<Student> records=repository.findAll(pageable);
		if(!records.isEmpty())
			return records;
		else
		    throw new DataNotFoundException();
	}


	public String deleteRecordById(Long id) {
		repository.deleteById(id);
		return "Data Removed Success";
}


	public Student updateStudent(Student student) {
		return repository.save(student);
		 
	}


	
}
