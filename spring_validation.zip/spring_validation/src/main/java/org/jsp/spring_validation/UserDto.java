package org.jsp.spring_validation;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class UserDto {
	@Size(min = 3,max = 15,message = "* Enter between 3~15 Characters")
    private String name;
	@DecimalMin(value = "6000000000",message = "* Enter Proper Mobile number")
	@DecimalMax(value = "9999999999",message = "* Enter Proper Mobile number")
	@NotNull(message = "* It is Required")
    private Long mobile;
	@NotEmpty(message = "* Select any one Gender")
    private String gender;
	@Email(message = "* Enter Proper Email")
	@NotEmpty(message = "* It is Required")
    private String email;
	@Pattern(message = "* Enter the password more than 8 characters consisting of uppercase,lowecase,number and special characters" ,regexp = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")
    private String password;
	@Pattern(message = "* Enter the password more than 8 characters consisting of uppercase,lowecase,number and special characters" ,regexp = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$" )
    private String confirmPassword;
	@AssertTrue(message = "* It is compulsory to accept the terms")
    private boolean terms;
    
    //Getters and Setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public boolean isTerms() {
		return terms;
	}
	public void setTerms(boolean terms) {
		this.terms = terms;
	}
	
}
