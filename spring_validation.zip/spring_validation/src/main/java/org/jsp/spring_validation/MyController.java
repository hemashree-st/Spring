package org.jsp.spring_validation;

import javax.naming.Binding;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;

@Controller
public class MyController {

	@GetMapping("/")
	public String loadForm(UserDto userDto,Model model)
	{
		model.addAttribute(userDto);
		return "form.html";
	}
	
	@PostMapping("/submit")
	public String submit(@ModelAttribute @Valid UserDto userDto,BindingResult result)
	{
		if(!userDto.getPassword().equals(userDto.getConfirmPassword()))
		{
			result.rejectValue("confirmPassword", "error.confirmPassword", "* Password and Confirm password should match");
		}
			if(result.hasErrors())
		        return "form.html";
			else
				return "redirect:https://www.youtube.com";
		
		
	}
}
