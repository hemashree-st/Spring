package org.jsp.Product_rest.entity;

import org.jsp.Product_rest.dto.ProductDTO;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Product {
	      @Id
	      @GeneratedValue(generator="id")
	      @SequenceGenerator(initialValue = 101,allocationSize = 1,name="id")
          private Long id;
          private String name;
          private Double price;
          private Integer quantity;
          
          
          public Product(ProductDTO dto)
          {
        	  this.name=dto.getName();
        	  this.price=dto.getPrice();
        	  this.quantity=dto.getQuantity();
          }
}
