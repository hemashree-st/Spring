package org.jsp.Product_rest.service;

import org.jsp.Product_rest.dto.ProductDTO;
import org.jsp.Product_rest.entity.Product;
import org.jsp.Product_rest.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
 
	@Autowired
	ProductRepository repository;
	
	public Product saveProduct(ProductDTO dto) {

		Product product=new Product(dto);
	    repository.save(product);
		return product;
		
	}

}
