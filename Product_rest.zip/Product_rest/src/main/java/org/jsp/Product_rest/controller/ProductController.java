package org.jsp.Product_rest.controller;


import org.jsp.Product_rest.dto.ProductDTO;
import org.jsp.Product_rest.entity.Product;
import org.jsp.Product_rest.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

	@RestController
	@RequestMapping("/api/v1")
public class ProductController {
	    
		@Autowired
		ProductService service;
		
		@PostMapping("/product")
		public ResponseEntity<Product> saveProduct(@RequestBody ProductDTO dto)
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(service.saveProduct(dto));
		}
	}

