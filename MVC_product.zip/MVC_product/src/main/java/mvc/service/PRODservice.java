package mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;


import mvc.entity.Product;
import mvc.repository.PRODrepository;

@Service
public class PRODservice {
	    @Autowired
        PRODrepository repository;

		public String save(Product product, Model model) 
		{
			repository.save(product);
			model.addAttribute("success","Data saved successfully");
		    return "home.jsp";
		}

		public String findById(int id, Model model) 
		{
			Product product=repository.findById(id);
			if(product==null)
			{
				model.addAttribute("failure","No records found");
				return "home.jsp";
			}
			else
			{
				model.addAttribute("product",product);
				return "display.jsp";
			}
		}

		public String update(Product product, Model model) 
		{
			repository.update(product);
			model.addAttribute("success","Updated successfully");
			return "home.jsp";
		}

		public String deleteById(int id, Model model) 
		{
			
			boolean status=repository.delete(id);
			if(status)
			{
				model.addAttribute("success","Deleted successfully");
			}
			else
			{
				model.addAttribute("failure","Record not deleted");
			}
			return "home.jsp";
		}
}
