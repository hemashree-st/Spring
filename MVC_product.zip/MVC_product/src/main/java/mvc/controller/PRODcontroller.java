package mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import mvc.entity.Product;
import mvc.service.PRODservice;

@Controller
public class PRODcontroller{
	
	@Autowired
	PRODservice service;
	
	@GetMapping("/")
	public String loadMain()
	{
		return "home.jsp";
	}
	
	@GetMapping("/insert")
	public String loadInsert()
	{
		return "add.jsp";
	}
	
	@PostMapping("/insert")
	public String insert(@ModelAttribute Product product,Model model)
	{
		return service.save(product,model);
	}
	
	@GetMapping("/fetch")
	public String loadFetch()
	{
		return "fetch.jsp";
	}
	
	@PostMapping("/fetch")
	public String fetch(@RequestParam int id,Model model)
	{
		return service.findById(id,model);
	}
	
	@GetMapping("/update")
	public String loadUpdate()
	{
		return "update.jsp";
	}
	
	@PostMapping("/update")
	public String update(@ModelAttribute Product product,Model model)
	{
		return service.update(product,model);
	}
	
	@GetMapping("/delete")
	public String loadDelete()
	{
		return "delete.jsp";
	}
	
	@PostMapping("/delete")
	public String deleteById(@RequestParam int id,Model model)
	{
		return service.deleteById(id,model);
	}
	

}
