package mvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import mvc.entity.Product;



@Repository
public class PRODrepository {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("product");
    EntityManager manager=factory.createEntityManager();
    EntityTransaction transaction=manager.getTransaction();
    
    //creating and to save records
    public boolean save(Product product)
    {
//    	transaction.begin();
    	try 
    	{
    		transaction.begin();
    	    manager.persist(product);
    	    transaction.commit();
    	    
    	    return true;
    	}
    	catch(Exception e) 
    	{
    		
    		return false;
    	}
    }
    
    //to fetch the records-->we will not use transaction.begin,commit because it is used only when the operation is affecting the database
    public Product findById(int id)
    {
    	return manager.find(Product.class,id);
    }
    
    //to update the records
    public boolean update(Product product)
    {
    	try 
        {
    	   transaction.begin();
    	   manager.merge(product);
    	   transaction.commit();
		   return true;
        }
        catch(Exception e) 
    	{
    	   transaction.commit();
    	   return false;
        }
    }
    
    //to delete the records
    public boolean delete(int id)
    {
    	try
    	{
    	  transaction.begin();
    	  manager.remove(findById(id));
    	  transaction.commit();
		  return true;
    	}
    	catch(Exception e)
    	{
    		transaction.commit();
    		return false;
    	}
    }
}


