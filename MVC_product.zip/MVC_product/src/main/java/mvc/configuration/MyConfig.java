package mvc.configuration;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("mvc")
public class MyConfig {

}
