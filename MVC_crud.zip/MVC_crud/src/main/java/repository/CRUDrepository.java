package repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import entity.User;
@Repository

public class CRUDrepository {
        EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
        EntityManager manager=factory.createEntityManager();
        EntityTransaction transaction=manager.getTransaction();
        
        //creating and to save records
        public boolean save(User user)
        {
//        	transaction.begin();
        	try 
        	{
        		transaction.begin();
        	    manager.persist(user);
        	    transaction.commit();
        	    
        	    return true;
        	}
        	catch(Exception e) 
        	{
        		
        		return false;
        	}
        }
        
        //to fetch the records-->we will not use transaction.begin,commit because it is used only when the operation is affecting the database
        public User findById(int id)
        {
        	return manager.find(User.class,id);
        }
        
        //to update the records
        public boolean update(User user)
        {
        	try 
            {
        	   transaction.begin();
        	   manager.merge(user);
        	   transaction.commit();
			   return true;
            }
            catch(Exception e) 
        	{
        	   transaction.commit();
        	   return false;
            }
        }
        
        //to delete the records
        public boolean delete(int id)
        {
        	try
        	{
        	  transaction.begin();
        	  manager.remove(findById(id));
        	  transaction.commit();
			  return true;
        	}
        	catch(Exception e)
        	{
        		transaction.commit();
        		return false;
        	}
        }
}
