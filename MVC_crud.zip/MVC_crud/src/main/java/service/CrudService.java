  package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import entity.User;
import repository.CRUDrepository;

@Service
public class CrudService {

	@Autowired
	CRUDrepository repository;
	
	public String save(User user,Model model)
	{
		boolean status=repository.save(user);
		
		if(status)
		{
			model.addAttribute("success","Data saved successfully");
		}
		else
		{
			model.addAttribute("failure","Did not save");
		}
		return "home.jsp";
	}
	
	
    public String findById(int id, Model model) 
    {
		User user=repository.findById(id);
		if(user==null)
		{
			model.addAttribute("failure","No records found");
			return "home.jsp";
		}
		else
		{
			model.addAttribute(user);
			return "display.jsp";
		}
		
	}


	public String update(User user, Model model) 
	{
		boolean status=repository.update(user);
		if(status)
		{
			model.addAttribute("success","Updated successfully");
		}
		else
		{
			model.addAttribute("failure","Did not updated");
		}
		return "home.jsp";
	}

	public String deleteById(int id, Model model) 
	{
		boolean status=repository.delete(id);
		if(status)
		{
			model.addAttribute("success","Deleted successfully");
		}
		else
		{
			model.addAttribute("failure","Record not deleted");
		}
		return "home.jsp";
	}


	

	
}
