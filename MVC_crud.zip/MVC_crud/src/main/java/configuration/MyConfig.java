package configuration;

import org.springframework.context.annotation.ComponentScan;


@ComponentScan("configuration,controller,service,entity,repository")
public class MyConfig {

}
