package Servletotp;

import java.io.IOException;
import java.util.Random;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Color")
public class Color extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Random rand=new Random();
		int r=rand.nextInt(256);
		int g=rand.nextInt(256);
		int b=rand.nextInt(256);
		
		String color="rgb("+r+","+g+","+b+")";
		
		res.getWriter().print("<html><body style='background-color:"+color+";'>");
		res.getWriter().print("</body></html>");
		
	}

}
